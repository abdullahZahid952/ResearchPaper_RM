"""
fetch_ood.py -- get a REAL-domain object dataset and write it as COCO-style json + images.
Order: (0) manual override  (1) anything you attached under /kaggle/input (COCO json or Pascal-VOC xml)
       (2) Hugging Face dataset ids (OOD_HF_ID first, then known DIOR aerial copies).
Only the first N_SCAN images are streamed; we keep images that contain >=3 different object classes.
"""
import os, sys, json, glob, io
import xml.etree.ElementTree as ET

OUT = os.path.join(os.environ.get("WORKDIR", "/kaggle/working"), "ood_src")
IMG = os.path.join(OUT, "images"); os.makedirs(IMG, exist_ok=True)
N_SCAN = int(os.environ.get("OOD_N_SCAN", "4000")); N_KEEP = 300; MINC = 3

def finish(images, anns, cats, source):
    json.dump(dict(images=images, annotations=anns, categories=[dict(id=i, name=n) for i, n in cats.items()]), open(os.path.join(OUT, "coco.json"), "w"))
    print(f"FETCH OK from {source}: {len(images)} images, {len(cats)} classes: {sorted(cats.values())[:25]}", flush=True)
    sys.exit(0)

# ---------------- (1) attached datasets ----------------
def from_input():
    root = os.environ.get("KAGGLE_INPUT", "/kaggle/input")
    if not os.path.isdir(root):
        return
    files = {}
    for dp, _, fs in os.walk(root):
        for f in fs:
            files.setdefault(f, os.path.join(dp, f))
    # COCO json
    for p in [v for k, v in files.items() if k.endswith(".json") and os.path.getsize(v) < 400e6]:
        try:
            d = json.load(open(p))
        except Exception:
            continue
        if isinstance(d, dict) and {"images", "annotations", "categories"} <= set(d):
            have = [i for i in d["images"] if i["file_name"].split("/")[-1] in files]
            if len(have) >= 50:
                keep = {}; images = []; anns = []
                for i in have:
                    shutil_copy(files[i["file_name"].split("/")[-1]], os.path.join(IMG, i["file_name"].split("/")[-1])); keep[i["id"]] = 1
                    images.append(dict(id=i["id"], file_name=i["file_name"].split("/")[-1]))
                anns = [dict(image_id=a["image_id"], category_id=a["category_id"]) for a in d["annotations"] if a["image_id"] in keep]
                finish(images, anns, {c["id"]: c["name"] for c in d["categories"]}, f"attached COCO json {p}")
    # Pascal VOC xml
    xmls = [v for k, v in files.items() if k.endswith(".xml")][:60000]
    if len(xmls) >= 50:
        cats = {}; images = []; anns = []; n = 0
        for p in xmls:
            try:
                r = ET.parse(p).getroot()
            except Exception:
                continue
            fn = (r.findtext("filename") or os.path.basename(p)[:-4] + ".jpg").split("/")[-1]
            src = files.get(fn) or next((files[fn[:-4] + e] for e in (".jpg", ".png", ".jpeg") if fn[:-4] + e in files), None)
            names = {o.findtext("name") for o in r.findall("object") if o.findtext("name")}
            if src is None or len(names) < MINC:
                continue
            n += 1; shutil_copy(src, os.path.join(IMG, os.path.basename(src)))
            images.append(dict(id=n, file_name=os.path.basename(src)))
            for nm in names:
                cid = cats.setdefault(nm, len(cats) + 1); anns.append(dict(image_id=n, category_id=cid))
            if n >= N_KEEP:
                break
        if len(images) >= 50:
            finish(images, anns, {v: k for k, v in cats.items()}, "attached Pascal-VOC xml")

def shutil_copy(a, b):
    import shutil
    if not os.path.exists(b):
        shutil.copy(a, b)

# ---------------- (2) Hugging Face ----------------
def from_hf(ds_id):
    from datasets import load_dataset
    ds = None
    for sp in ("train", "test", "validation", "val"):
        try:
            ds = load_dataset(ds_id, split=sp, streaming=True); print(f"  loaded {ds_id} split={sp}", flush=True); break
        except Exception as e:
            print(f"  split {sp}: {type(e).__name__}: {str(e)[:120]}", flush=True)
    if ds is None:
        return False
    feats = getattr(ds, "features", None)
    names = None; img_col = None; obj_col = None
    if feats:
        for k, v in feats.items():
            if v.__class__.__name__ == "Image" and img_col is None:
                img_col = k
        for k in ("objects", "annotations", "labels", "label"):
            if k in feats:
                obj_col = k
        try:
            sub = feats[obj_col]
            for key in ("category", "label", "category_id", "class"):
                f = sub.feature[key] if hasattr(sub, "feature") and isinstance(sub.feature, dict) else None
                if f is not None and hasattr(f, "names"):
                    names = f.names; break
        except Exception:
            pass
    if names is None and ds_id == "Marcel031/dior":   # class ids 0..19 listed in that dataset's README YAML header (alphabetical DIOR order)
        names = ["Airplane", "Airport", "Baseball field", "Basketball court", "Bridge", "Chimney", "Dam", "Expressway service area",
                 "Expressway toll station", "Golf course", "Ground track field", "Harbor", "Overpass", "Ship", "Stadium", "Storage tank",
                 "Tennis court", "Train station", "Vehicle", "Wind mill"]
        print("  using the 20 DIOR class names from the dataset README", flush=True)
    images, anns, cats = [], [], {}
    seen = 0
    for ex in ds:
        seen += 1
        if seen == 1:
            print("  example keys:", {k: type(v).__name__ for k, v in ex.items()}, flush=True)
            if isinstance(ex.get(obj_col or "objects"), dict):
                print("  objects keys / first values:", {k: (v[:3] if isinstance(v, list) else v) for k, v in ex[obj_col or "objects"].items()}, "| class names known:", names is not None, flush=True)
            if img_col is None:
                img_col = next((k for k, v in ex.items() if hasattr(v, "convert")), None)
            if obj_col is None:
                obj_col = next((k for k in ("objects", "annotations", "labels", "label") if k in ex), None)
            if img_col is None or obj_col is None:
                print("  cannot find image/object columns", flush=True); return False
        o = ex[obj_col]; cl = []
        if isinstance(o, dict):
            for key in ("category", "label", "category_id", "class", "categories", "labels"):
                if key in o:
                    cl = o[key]; break
        elif isinstance(o, list):
            for a in o:
                if isinstance(a, dict):
                    for key in ("category_id", "category", "label", "name"):
                        if key in a:
                            cl.append(a[key]); break
        elif isinstance(o, (int, str)):
            cl = [o]
        def nm(c):
            if isinstance(c, str):
                return c
            return names[int(c)] if names is not None and 0 <= int(c) < len(names) else None
        cs = {nm(c) for c in cl if nm(c)}
        if seen % 500 == 0:
            print(f"  scanned {seen}, kept {len(images)}", flush=True)
        if len(cs) >= MINC:
            fn = f"ood_{len(images):04d}.jpg"
            ex[img_col].convert("RGB").save(os.path.join(IMG, fn), quality=92)
            images.append(dict(id=len(images) + 1, file_name=fn))
            for c in cs:
                cid = cats.setdefault(c, len(cats) + 1); anns.append(dict(image_id=len(images), category_id=cid))
        if len(images) >= N_KEEP or seen >= N_SCAN:
            break
    print(f"  {ds_id}: scanned {seen}, kept {len(images)} images with >={MINC} classes", flush=True)
    if len(images) >= 40:
        finish(images, anns, {v: k for k, v in cats.items()}, f"Hugging Face {ds_id}")
    return False

if os.environ.get("OOD_HF_ID") != "SKIPALL":
    print("trying attached Kaggle inputs ...", flush=True)
    from_input()
    cand = [c for c in [os.environ.get("OOD_HF_ID", "")] if c] + ["Marcel031/dior", "HOHKUIK/DIOR"]
    for c in cand:
        print("trying Hugging Face dataset", c, flush=True)
        try:
            from_hf(c)
        except SystemExit:
            raise
        except Exception as e:
            print(f"  failed: {type(e).__name__}: {str(e)[:200]}", flush=True)
print("FETCH FAILED: no real-domain dataset could be loaded automatically.")
sys.exit(3)
